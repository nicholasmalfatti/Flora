document.getElementById("loaded").textContent = "✅ app.js caricato (versione debug v3)";
function $(id){ return document.getElementById(id); }

async function sync(){
  const btn = $("syncBtn");
  btn.disabled = true;
  $("status").textContent = "Scaricando da Wikidata…";
  $("lastErr").textContent = "(in corso)";
  const sparql = `
PREFIX wd: <http://www.wikidata.org/entity/>
PREFIX wdt: <http://www.wikidata.org/prop/direct/>
PREFIX wikibase: <http://wikiba.se/ontology#>
PREFIX bd: <http://www.bigdata.com/rdf#>
SELECT ?taxon ?taxonLabel ?sciName WHERE {
  ?taxon wdt:P105 wd:Q7432 .
  ?taxon wdt:P171* wd:Q756 .
  OPTIONAL { ?taxon wdt:P225 ?sciName . }
  SERVICE wikibase:label { bd:serviceParam wikibase:language "it,en". }
  FILTER(LANG(?taxonLabel)="it")
}
LIMIT 500
`;
  const url = "https://query.wikidata.org/sparql?format=json&query=" + encodeURIComponent(sparql);
  $("lastUrl").value = url;

  try{
    const res = await fetch(url, { headers: { "Accept":"application/sparql-results+json" } });
    const text = await res.text();
    if(!res.ok){
      throw new Error("HTTP " + res.status + " " + res.statusText + "\n\n" + text.slice(0, 1500));
    }
    let json;
    try{ json = JSON.parse(text); }catch{ throw new Error("Risposta non-JSON (primi 800 char):\n" + text.slice(0, 800)); }

    const rows = json?.results?.bindings || [];
    $("status").textContent = "✅ Sync OK: " + rows.length + " righe";
    $("lastErr").textContent = "OK. Prime 2 righe:\n" + JSON.stringify(rows.slice(0,2), null, 2);
  }catch(e){
    $("status").textContent = "❌ Errore sync (vedi dettagli sotto)";
    $("lastErr").textContent = String(e);
  }finally{
    btn.disabled = false;
  }
}

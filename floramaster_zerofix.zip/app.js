function $(id){ return document.getElementById(id); }

async function sync(){
  const btn = $("syncBtn");
  btn.disabled = true;
  $("status").textContent = "Scaricando da Wikidata…";
  $("debug").textContent = "(in corso)";

  // IMPORTANT: non filtriamo più LANG(it) perché molte specie non hanno label IT.
  // Preferenza nome visualizzato: IT > EN > LA > scientifico (P225) > label qualsiasi.
  const sparql = `
PREFIX wd: <http://www.wikidata.org/entity/>
PREFIX wdt: <http://www.wikidata.org/prop/direct/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
PREFIX wikibase: <http://wikiba.se/ontology#>
PREFIX bd: <http://www.bigdata.com/rdf#>

SELECT ?taxon ?labelIT ?labelEN ?labelLA ?anyLabel ?sciName WHERE {
  ?taxon wdt:P105 wd:Q7432 .     # species
  ?taxon wdt:P171* wd:Q756 .     # descendant of Plantae

  OPTIONAL { ?taxon wdt:P225 ?sciName . }
  OPTIONAL { ?taxon rdfs:label ?labelIT FILTER(LANG(?labelIT)="it") }
  OPTIONAL { ?taxon rdfs:label ?labelEN FILTER(LANG(?labelEN)="en") }
  OPTIONAL { ?taxon rdfs:label ?labelLA FILTER(LANG(?labelLA)="la") }
  OPTIONAL { ?taxon rdfs:label ?anyLabel }

}
LIMIT 2000
`;

  const url = "https://query.wikidata.org/sparql?format=json&query=" + encodeURIComponent(sparql);

  try{
    const res = await fetch(url, { headers: { "Accept":"application/sparql-results+json" } });
    const json = await res.json();
    const rows = json?.results?.bindings || [];

    const plants = rows.map(r=>{
      const sci = r.sciName?.value || "";
      const it = r.labelIT?.value || r.labelEN?.value || r.labelLA?.value || sci || r.anyLabel?.value || "";
      return { it, sci: sci || it };
    }).filter(p => p.it);

    localStorage.setItem("floraDB", JSON.stringify({
      savedAt: Date.now(),
      count: plants.length,
      plants
    }));

    $("status").textContent = `✅ Sync completato: ${plants.length} voci salvate.`;
    $("debug").textContent = JSON.stringify(plants.slice(0,5), null, 2);
  }catch(e){
    $("status").textContent = "❌ Errore sync";
    $("debug").textContent = String(e);
  }finally{
    btn.disabled = false;
  }
}
